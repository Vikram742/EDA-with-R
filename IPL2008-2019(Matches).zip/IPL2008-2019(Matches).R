matches<- read.csv("D:/IIMK/R Basic/EDA/IPL/matches.csv")
#let's look at the records
head(matches)
names(matches)
#I want to drop the columns having umpire details
matches1<-matches[,1:15]
#let's look at the data types of all the columns
str(matches1)
#change the data type of columns date from character to date
#run libraries
library(dplyr)
library(tidyr)
library(tidyverse)
library(ggplot2)
library(janitor)
library(lubridate)

matches1$date<-as.Date(matches1$date)
#change the team names to abbreviations
unique(matches1$team1)
unique(matches1$team2)
unique(matches1$toss_winner)
unique(matches1$winner)
matches1<-matches1 %>% 
  mutate(team1 = recode(team1,
                        "Sunrisers Hyderabad"="SRH",
                        "Mumbai Indians" = "MI",
                        "Gujarat Lions" = "GL",
                        "Rising Pune Supergiant" = "RPSG",
                        "Royal Challengers Bangalore" = "RCB",
                        "Kolkata Knight Riders" = "KKR",
                        "Delhi Daredevils" = "DD",
                        "Kings XI Punjab" = "KXIP",
                        "Chennai Super Kings" = "CSK",
                        "Rajasthan Royals" = "RR",
                        "Deccan Chargers" ="DCH",
                        "Kochi Tuskers Kerala" = "KTK",
                        "Pune Warriors" = "PW",
                        "Rising Pune Supergiants" = "RPSG",
                        "Delhi Capitals" = "DC"))

#Since these team names are present across a few columns we can rename them using one command
matches1<-matches1 %>% 
  mutate(across(c(team2,toss_winner,winner),~recode(.,
                                                    "Royal Challengers Bangalore" = "RCB",
                                                    "Rising Pune Supergiant" = "RPSG",
                                                    "Kolkata Knight Riders" = "KKR",
                                                    "Kings XI Punjab" = "KXIP",
                                                    "Delhi Daredevils" = "DD",
                                                    "Sunrisers Hyderabad" = "SRH",
                                                    "Mumbai Indians" = "MI",
                                                    "Gujarat Lions" = "GL",
                                                    "Rajasthan Royals" = "RR",
                                                    "Chennai Super Kings" = "CSK",
                                                    "Deccan Chargers" = "DCH",
                                                    "Pune Warriors" = "PW",
                                                    "Kochi Tuskers Kerala" = "KTK",
                                                    "Rising Pune Supergiants" = "RPSG",
                                                    "Delhi Capitals" = "DC",
                                                    )))

## Some dates have gone missing in the date column. Let's try to fill it

matches1<-matches1 %>% 
  mutate(date = case_when(
    id == 7894 & is.na(date) ~ as.Date("2018-04-07"),
    id = 7895 & is.na(date)~ as.Date("2018-04-08"),
    TRUE~ date
  ))

unique(matches1$venue)
table(matches1$venue)
#There are many venues which are the same but one word has been added or deleted from the same. So let's fix it.
matches1<-matches1 %>% 
  mutate(venue = recode(venue,
                        "IS Bindra Stadium" = "Punjab Cricket Association Stadium, Mohali",
                        "Punjab Cricket Association IS Bindra Stadium, Mohali" =  "Punjab Cricket Association Stadium, Mohali",
                        "Dr. Y.S. Rajasekhara Reddy ACA-VDCA Cricket Stadium" ="ACA-VDCA Stadium",
                        "Feroz Shah Kotla Ground" = "Feroz Shah Kotla",
                        "M Chinnaswamy Stadium"="M. Chinnaswamy Stadium",
                        "M. A. Chidambaram Stadium" = "MA Chidambaram Stadium, Chepauk" ,
                        "Rajiv Gandhi Intl. Cricket Stadium" = "Rajiv Gandhi International Stadium, Uppal"
                        ))
table(matches1$venue)

# I want to see the Venues and the City
matches1 %>% 
  select(city,venue) %>% 
  group_by(city,venue) %>% 
  arrange(city,venue)

venue_cities <- matches1 %>%
  group_by(venue) %>%
  summarise(cities = paste(unique(city), collapse = ", ")) %>%
  arrange(cities)
 
remove(venue_cities)
print(venue_cities)

#I have also noticed that some records in column "city" needs changing
matches1 <- matches1 %>%
  mutate(city = ifelse(is.na(city)| city == "","Dubai",city))

#Let's check if there are any NA values in column "city"
sum(is.na(matches1$city))
#No NA values 

matches1<-matches1 %>% 
  mutate(city = ifelse(venue == "M Chinnaswamy Stadium","Bangalore",city))

matches1<-matches1 %>% 
  mutate(city = ifelse(venue == "M. Chinnaswamy Stadium","Bangalore",city))

matches1<-matches1 %>% 
  mutate(city = ifelse(venue =="Punjab Cricket Association Stadium, Mohali","Mohali",city))

table(matches1$city)

##EXPLORATORY DATA ANALYSIS
#1. How many matches were played in each season.

matches1 %>% 
  group_by(season) %>% 
  summarise(n=n()) %>% 
  ggplot(aes(x = season, y = n))+
  geom_bar(stat = 'identity',position = 'dodge', fill = 'lightblue')+
  geom_label(aes(label = n))+
  theme_bw()+
  labs(x = "Season", y = "No of Matches", title = "Matches Played across each Season")+
  theme(axis.text.y = element_blank(),
        axis.text.x = element_text(size = 10),
        panel.grid = element_blank(),
        plot.title = element_text(hjust = 0.5))
  
# X axis is being show as 2007.5 , 2010.5. This is because it treats "Season" column as numerical. We need to convert it to
# a factor vector 

matches1$season<-as.factor(matches1$season)
matches1 %>% 
  group_by(season) %>% 
  summarise(n=n()) %>% 
  ggplot(aes(x = season, y = n))+
  geom_bar(stat = 'identity', position = 'dodge', fill = 'lightblue')+
  geom_label(aes(label = n))+
  theme_bw()+
  theme(panel.grid = element_blank())+
  labs(x = 'Season', y = 'Matches Played', title = 'Matches Played Across Seasons')+
  theme(axis.text.y = element_blank(), plot.title = element_text(hjust = 0.5))
###. 2011(73), 2012(74),2013(76) had the highest number of matches
  
#2. Top 5 venues by matches hosted

matches1 %>% 
  group_by(venue) %>% 
  summarise(n=n()) %>% 
  arrange(desc(n)) %>% 
  head(5) %>% 
  ggplot(aes(x = reorder(venue,desc(n)), y= n))+
  geom_bar(stat = 'identity',position = 'dodge', fill ='lightblue')+
  geom_label(aes(label = n))+
  theme_bw()+
  labs(y = 'Matches Hosted', x = 'Venue', title = 'Matches Hosted by Venue')+
  theme(axis.text.y = element_blank(), 
        axis.text.x = element_text(angle = 45,hjust = 1),
        plot.title = element_text(hjust = 0.5),
        panel.grid = element_blank())
#  M. Chinnaswamy Stadium  (80), Eden Gardens (77), Feroz Shah Kotla(74),  Wankhede Stadium (73), , 
# Rajiv Gandhi International Stadium, Uppal (64)

#3. Which team had the highest win by margin of runs and provide the details for the same
matches1 %>% 
  select(season,date,winner,team2,win_by_runs,venue) %>% 
  arrange(-win_by_runs) %>% 
  head(1)
#MI had the highest win by margin of runs (146) against DD at Feroz Shah Kotla on "2017-05-06"

#4. Which team had the highest win by margin of wickets and provide the details for the same
matches1 %>% 
  select(season,date,winner,team1,win_by_wickets,venue) %>% 
  arrange(-win_by_wickets) %>% 
  head(11)
#Teams with 10 wickets win include RCB(3 times), KKR,KXIP, DCH,DD, RR,MI,CSK,SRH,(All 1 time)

#5. Top 5 players with the maximum player of the match awards

  matches1 %>% 
  group_by(player_of_match) %>% 
  summarise(n=n()) %>%
  arrange(-n) %>% 
  head(5) %>% 
  ggplot(aes(x = reorder(player_of_match,desc(n)), y = n))+
  geom_bar(stat = 'identity', fill = "lightblue" )+
  labs(x = 'Player', y = 'Awards Won', title = 'Player of the Match Awards Won')+
  theme_bw()+
  geom_label(aes(label = n))+
  theme(axis.text.y = element_blank(),
        axis.text.x = element_text(size = 12),
        plot.title = element_text(hjust = 0.5),
        panel.grid = element_blank())
#Chris Gayle has won the Player of the Match a record 21 times followed by AB de Villiers (20), David Warner, MS Dhoni,
# Rohit Sharma (17 each)

################################################# Mumbai Indians (MI)
  
#Create a separate data frame that consists of matches played only by MI
MI_team<- matches1 %>% 
          select(season,date,team1,team2,winner) %>% 
          filter(team1== "MI"
                 |team2=="MI")  
  
#Summary of total matches played vs matches won by MI (All Seasons)
MI_team %>% 
   summarise(Matches_Played=n(),
             Matches_won = sum(winner=="MI")) %>% 
  pivot_longer(cols = everything(), names_to = "Category", values_to = "Count") %>% 
  ggplot(aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", show.legend = FALSE) +
  labs(
    x = "Category",
    y = "Count",
    title = "Matches Played vs Matches Won by MI (2008-2019)"
  ) +
  theme_bw() +
  geom_label(aes(label = Count))+
  theme(plot.title = element_text(hjust = 0.5, size = 16),
        axis.text.y = element_blank(),
        panel.grid = element_blank(),
        legend.position = "none")
  
# Matches Played = 187 , Matches Won = 109, Win Ratio = 58.28%

#Show Win Percentage Ratio for all Seasons for MI
MI_team %>% 
  group_by(season) %>% 
  summarise(Matches_Played = n(),
            Matches_Won = sum(winner == "MI"),
            Win_Percentage = round(sum(winner == "MI") / n() *100,2)) %>% 
  ggplot(aes(x = season, y = Win_Percentage))+
  geom_bar(stat='identity', fill = "#004B8D")+
  geom_label(aes(label = Win_Percentage))+
  labs(x = "Season", y = "Win Percentage", title = "Win Percentage for MI in IPL (2008-2019)")+
  theme_bw()+
  theme(panel.grid = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 12),
        plot.title = element_text(hjust = 0.5))




#Create a separate dataframe containing a summary of total matches played, total matches won, total win% ratio for MI
MI_Team_Win_Ratio<- MI_team %>% 
  summarise(Team = "MI",
            Matches_Played = n(),
            Matches_Won = sum(winner=="MI"),
            Winning_Percentage = round(sum(winner=="MI")/n()*100,2))

# Matches Played = 187 , Matches Won = 109, Win Ratio = 58.28%
######################################################### ROYAL CHALLENGERS BANGALORE (RCB)
RCB_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="RCB"|team2=="RCB")

###Season wise Winning Percentage for RCB
RCB_Team %>% 
  group_by(season) %>% 
  summarise(Matches_Played = n(),
            Matches_Won = sum(winner == "RCB"),
            Winning_Percentage = round(sum(winner == "RCB")/ n()*100,2)) %>% 
  ggplot(aes(x = season, y = Winning_Percentage))+
  geom_bar(stat = 'identity', fill = "#2B2A29")+
  geom_label(aes(label = Winning_Percentage))+
  theme_bw()+
  labs(x = 'Season', y = 'Win Percentage', title = 'Win Percentage for MI in IPL (2008-2019)')+
  theme(panel.grid = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size = 12))
#Highest winning percentage was 62.5% in 2011 and lowest was 23.08% in 2017.

#Create a separate dataframe containing a summary of total matches played, total matches won, total win% ratio for RCB
RCB_Team_Win_Ratio<- RCB_Team %>% 
  summarise(Team = "RCB",
         Matches_Played = n(),
         Matches_Won = sum(winner=="RCB"),
         Winning_Percentage = round(sum(winner=="RCB") / n() *100,2))
# Matches Played = 180 , Matches Won = 84, Win Ratio = 46.67%
######################################################### KOLKATA KNIGHT RIDERS (KKR)
KKR_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="KKR"|team2 =="KKR")

KKR_Team_Win_Ratio<-KKR_Team %>% 
  summarise(Team = "KKR",
            Matches_Played = n(),
            Matches_Won = sum(winner == "KKR"),
            Winning_Percentage = round(sum(winner == "KKR") / n() *100,2))
# Matches Played = 178 , Matches Won = 92, Win Ratio = 51.69%

######################################################### KINGS XI PUNJAB (KXIP)
KXIP_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="KXIP"|team2=="KXIP")

KXIP_Team_Win_Ratio<-KXIP_Team %>% 
  summarise(Team = "KXIP",
            Matches_Played = n(),
            Matches_Won = sum(winner=="KXIP"),
            Winning_Percentage = round(sum(winner== "KXIP") / n()*100,2))
# Matches Played = 176 , Matches Won = 82, Win Ratio = 46.59%

######################################################### CHENNAI SUPER KINGS (CSK)
CSK_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="CSK"|team2=="CSK")

CSK_Team_Win_Ratio<-CSK_Team %>% 
  summarise(Team = "CSK",
            Matches_Played = n(),
            Matches_Won = sum(winner=="CSK"),
            Winning_Percentage = round(sum(winner=="CSK") / n()*100,2))
# Matches Played = 164 , Matches Won = 100, Win Ratio = 60.98%

######################################################### DELHI DAREDEVILS (DD)
DD_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="DD"|team2=="DD")

DD_Team_Win_Ratio<-DD_Team %>% 
  summarise(Team = "DD",
            Matches_Played = n(),
            Matches_Won = sum(winner=="DD"),
            Winning_Percentage = round(sum(winner=="DD")/ n() *100,2))
# Matches Played = 161 , Matches Won = 67, Win Ratio = 41.61%

######################################################### DELHI CAPITALS (DC)
DC_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="DC"|team2=="DC")

DC_Team_Win_Ratio<-DC_Team %>% 
  summarise(Team = "DC",
            Matches_Played = n(),
            Matches_Won = sum(winner=="DC"),
            Winning_Percentage = round(sum(winner=="DC")/ n()*100,2))
# Matches Played = 16 , Matches Won = 10, Win Ratio = 62.5% (This will not be included in the final merge as a team should 
# play a minimum of 30 matches)

######################################################### Deccan Charges(DCH)
DCH_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="DCH"|team2=="DCH")

DCH_Team_Win_Ratio<-DCH_Team %>% 
  summarise(Team = "DCH",
            Matches_Played = n(),
            Matches_Won = sum(winner=="DCH"),
            Winning_Percentage = round(sum(winner=="DCH")/ n()*100,2))
# Matches Played = 75 , Matches Won = 29, Win Ratio = 38.67% 

######################################################### Gujarat Lions(GL)
GL_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="GL"|team2=="GL")

GL_Team_Win_Ratio<-GL_Team %>% 
  summarise(Team = "GL",
            Matches_Played = n(),
            Matches_Won = sum(winner=="GL"),
            Winning_Percentage = round(sum(winner=="GL")/ n()*100,2))
# Matches Played = 30 , Matches Won = 13, Win Ratio = 43.33% 

######################################################### Sun Risers Hyderabad(SRH)
SRH_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="SRH"|team2=="SRH")

SRH_Team_Win_Ratio<-SRH_Team %>% 
  summarise(Team = "SRH",
            Matches_Played = n(),
            Matches_Won = sum(winner=="SRH"),
            Winning_Percentage = round(sum(winner=="SRH")/ n()*100,2))
# Matches Played = 108 , Matches Won = 58, Win Ratio = 53.70% 

######################################################### Rising Pune Super Giants(RPSG)
RPSG_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="RPSG"|team2=="RPSG")

RPSG_Team_Win_Ratio<-RPSG_Team %>% 
  summarise(Team = "RPSG",
            Matches_Played = n(),
            Matches_Won = sum(winner=="RPSG"),
            Winning_Percentage = round(sum(winner=="RPSG")/ n()*100,2))
# Matches Played = 30 , Matches Won = 15, Win Ratio = 50.00% 

######################################################### RAJASTHAN ROAYLS (RR)
RR_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="RR"|team2=="RR")

RR_Team_Win_Ratio<-RR_Team %>% 
  summarise(Team = "RR",
            Matches_Played = n(),
            Matches_Won = sum(winner=="RR"),
            Winning_Percentage = round(sum(winner=="RR")/ n()*100,2))
# Matches Played = 147 , Matches Won = 75, Win Ratio = 51.02% 

######################################################### PUNE WARRIORS (PW)
PW_Team<-matches1 %>% 
  select(season,date,team1,team2,winner) %>% 
  filter(team1=="PW"|team2=="PW")

PW_Team_Win_Ratio<-PW_Team %>% 
  summarise(Team = "PW",
            Matches_Played = n(),
            Matches_Won = sum(winner=="PW"),
            Winning_Percentage = round(sum(winner=="PW")/ n()*100,2))
# Matches Played = 46 , Matches Won = 12, Win Ratio = 26.09% 

all_ipl_teams_win_ratio<-rbind(MI_Team_Win_Ratio,RCB_Team_Win_Ratio,KKR_Team_Win_Ratio,KXIP_Team_Win_Ratio,
                               CSK_Team_Win_Ratio,DD_Team_Win_Ratio,DCH_Team_Win_Ratio,GL_Team_Win_Ratio,
                               SRH_Team_Win_Ratio,RPSG_Team_Win_Ratio,RR_Team_Win_Ratio,PW_Team_Win_Ratio)

#Create a bar chart showing the Winning Percentage for all the teams over all the IPL seasons
# I want to give a different color to each team so I will create a new data frame for the same
team_colors<-c(
  "CSK" = "#f3ff33",
  "MI" = "#004B8D",
  "SRH" = "#FFA500",
  "RR" = "#FF1493",
  "RPSG" = "#800080",
  "RCB" = "#FF0000",
  "KXIP" = "#B2BEB5",
  "GL" = "#ADD8E6",
  "DD" = "#D2042D",
  "DCH"= "#00FFFF",
  "PW"= "#0096FF")
  

  

all_ipl_teams_win_ratio %>% 
  ggplot(aes(x = reorder(Team,desc(Winning_Percentage)), y = Winning_Percentage,fill=Team))+
  geom_bar(stat = 'identity',show.legend = FALSE)+
  geom_label(aes(label = Winning_Percentage),color = "black")+
  scale_fill_manual(values = team_colors)+
  theme_bw()+
  labs(x = "Team (*Minimum of 30 Matches Played)", y = "Winning Percentage", title = "Win Percent for IPL Teams (2008-2019")+
  theme(legend.position = "none",
        panel.grid = element_blank(),
        axis.text.y = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(size = 10))
# CSK has the highest win percentage 60.98 and PW has the lowest 26.09%


#### CORRELATION BETWEEN TOSS AND RESULT AT DIFFERENT VENUES
### 4 CHOICES: TOSS WON - BAT FIRST- MATCH WON, TOSS WON - BAT FIRST - MATCH LOST,
####           TOSS WON - FIELD FIRST - MATCH WON, TOSS WON - FIELD FIRST - MATCH LOST

matches2<- matches1 %>%
  select(everything()) %>% 
  mutate(outcome = case_when(
    toss_decision == "bat" & toss_winner == winner ~ "TOSS WON - BAT FIRST - MATCH WON" ,
    toss_decision == "bat" & toss_winner != winner ~ "TOSS WON - BAT FIRST - MATCH LOST",
    toss_decision == "field" & toss_winner == winner ~ "TOSS WON - FIELD FIRST - MATCH WON",
    toss_decision == "field" & toss_winner != winner ~ "TOSS WON - FIELD FIRST - MATCH LOST"
  ))

matches2 %>% 
  group_by(venue,outcome) %>% 
  summarise(count = n(),.groups = "drop") %>% 
  ggplot(aes(x = outcome, y = venue, fill = count))+
  geom_tile(color = 'white', fill = 'orange')+
  geom_label(aes(label = count, color = 'white'))
  theme(axis.text.x = element_text(angle = 45,hjust = 1))
  
### Observations about certain venues
##  M. Chinnaswamy Stadium  (80) matches : 4 matches where the team won the toss, batted first but 
## won the match. 39 matches where the team won the toss, fielded first and won the match. But another stat also
## suggest of 32 matches where the team won the toss, fielded first and lost the match.

##  Eden Gardens (77) matches : 12 matches where the team won the toss, batted first but 
## won the match. 31 matches where the team won the toss, fielded first and won the match. It is a clear indication
## that it is better to field first at this ground as the chances of winning are high.  
  
##  Feroz Shah Kotla(74) matches : 15 matches where the team won the toss, batted first but 
## won the match. 23 matches where the team won the toss, fielded first and won the match.
  

##  Wankhede Stadium (73) matches : 25 matches where team won the toss, fielded first but lost the match. Also there are 
## 26 matches where team won the toss, fielded first but won the match. There is no definitive picture of this venue. 

## Rajiv Gandhi International Stadium, Uppal (64) matches : 6 matches where the team won the toss, batted first but 
## won the match. 15 matches where the team won the toss, fielded first and won the match.

matches2 %>% 
 group_by(outcome) %>% 
 summarise(count =n()) 

### Out of the 756 matches, 259 times team has won toss, fielded first and won the match. This is about 1 in 3 matches.

#########################################################################################################################

  