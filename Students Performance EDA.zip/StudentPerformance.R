#set the working directory and read the data
students<-read.csv("StudentsPerformance.csv")
summary(students)
#check for missing data
sum(is.na(students))
#check for duplicated rows
sum(duplicated(students))
# check data types of all variables 
str(students)
students$gender<-factor(students$gender)
students$race.ethnicity<-factor(students$race.ethnicity)
students$parental.level.of.education<-factor(students$parental.level.of.education)
students$lunch<-factor(students$lunch)
students$test.preparation.course<-factor(students$test.preparation.course)

# Run libraries
library(dplyr)
library(ggplot2)
library(tidyr)

#rename certain columns as they are very long
students<- students %>% 
  rename(race = race.ethnicity,
         parents_edu = parental.level.of.education,
         test_prep = test.preparation.course)

#We want to predict the average scores so we need to create a column for the same
students<- students %>% 
  mutate(avg_score = (math.score + reading.score + writing.score)/3)

#find unique values in each column
table(students$gender)
table(students$race)
table(students$parents_edu)
table(students$lunch)
table(students$test_prep)

#count of female and male students
students %>% 
  group_by(gender) %>% 
  summarise(n = n()) %>% 
  ggplot(aes(x = gender, y = n, fill= gender))+
  geom_bar(stat='identity')+
  geom_label(aes(label = n))+
  theme_bw()+
  labs(title = 'Total Count of Female and Male Students', x = 'Gender', y= 'Count of Students')


#count of females and males via race
students %>% 
  group_by(gender, race) %>% 
  summarise(n = n()) %>%   
  ggplot(aes(x = reorder(race,-n), y = n, fill= gender))+
  geom_bar(stat='identity', position = 'dodge')+
  geom_label(aes(label = n),position = position_dodge(width = 0.9))+
  theme_bw()+
  labs(title = 'Total Count of Female and Male Students with regards to Race', x = 'Race', y= 'Count of Students')

#count of student's Parents Education
students %>% 
  group_by(parents_edu) %>% 
  summarise(n=n()) %>% 
 ggplot(aes(x = reorder(parents_edu,n), y = n, fill = parents_edu))+
  geom_bar(stat = 'identity')+
  coord_flip()+
  theme_bw()+
  geom_label(aes(label =n))+
  labs(title = 'Total Count of Parents Education', y = 'Count of Students', x = 'Parents Education')

#count of student's lunch type
students %>% 
  group_by(gender,lunch) %>% 
  summarise(n = n()) %>% 
  ggplot(aes(x = lunch, y = n , fill = gender))+
  geom_bar(stat = 'identity', position ='dodge')+
  theme_bw()+
  geom_label(aes(label=n),position = position_dodge(width = 0.9))+
  labs(title = 'Total Count of students via Lunch Type', x = 'Lunch Type', y = 'Count of Male and Female Students')

#male and female student's average scores
students %>% 
  group_by(gender) %>% 
  summarise(total_avg_score = sum(avg_score)) %>% 
  ggplot(aes(x = gender, y = total_avg_score, fill = gender))+
  geom_bar(stat = 'identity')+
  geom_label(aes(label = round(total_avg_score)))+
  theme_bw()+
  labs(title = 'Female & Male Students Total Average Score', x = 'Gender', y = 'Total Average Score')

#male and female student's test preparation
students %>% 
  group_by(gender,test_prep) %>% 
  summarise(n = n()) %>% 
  ggplot(aes(x = test_prep, y = n, fill = gender))+
  geom_bar(stat = 'identity', position = 'dodge')+
  geom_label(aes(label = n), position = position_dodge(width = 0.9))+
  theme_bw()+
  labs(title = 'Total Count of female and male students test preparation', x = 'test preparation', y = 'Count of Students')

#correlation plot
score<-c("math.score","reading.score","writing.score")
score<-students[score]
score1<-cor(score)  
library(corrplot)
corrplot(score1, method = "color",addCoef.col = "white")

#Conclusion from the above visualizations

#1) Female students (518) are more represented than male students (482). Total 1000 
#2) Most students belong to Group C Race (180- females and 139-males), Total= 319 and the least number of students belong
# to Group A race (53-females and 36-males) Total = 89
#3) 226 students parents education is of some college followed closely by associate's degree (222). 59 students
#parents have a master's degree
#4) 355 students have free or reduced lunch versus 645 students who get standard lunch
#5) Females students total average score is more than that of male students. This could also be due to higher
#proportion of female students
#6) 358 students had completed the test preparations versus 642 students who had not completed
#7) The correlation is the highest between writing score and reading score (0.95)




